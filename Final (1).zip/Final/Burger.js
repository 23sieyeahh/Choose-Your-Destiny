(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Burger_atlas_1", frames: [[0,0,1856,1033]]},
		{name:"Burger_atlas_2", frames: [[0,0,1453,1019],[0,1021,1453,1019]]},
		{name:"Burger_atlas_3", frames: [[1571,270,119,64],[1442,348,144,54],[1650,52,60,60],[1650,0,105,50],[1162,0,278,434],[1442,179,181,89],[1442,0,206,88],[1442,270,127,76],[1442,90,186,87],[-936660108,4,-1040187284,-788529043],[889,580,604,55],[0,580,887,41],[0,0,1160,578]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_15 = function() {
	this.initialize(ss["Burger_atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_14 = function() {
	this.initialize(ss["Burger_atlas_3"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4 = function() {
	this.initialize(ss["Burger_atlas_3"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_13 = function() {
	this.initialize(ss["Burger_atlas_3"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_12 = function() {
	this.initialize(ss["Burger_atlas_3"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_10 = function() {
	this.initialize(ss["Burger_atlas_3"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_9 = function() {
	this.initialize(ss["Burger_atlas_3"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_21 = function() {
	this.initialize(ss["Burger_atlas_3"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_20 = function() {
	this.initialize(ss["Burger_atlas_3"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_23 = function() {
	this.initialize(ss["Burger_atlas_3"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_7 = function() {
	this.initialize(ss["Burger_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_2 = function() {
	this.initialize(ss["Burger_atlas_3"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_1 = function() {
	this.initialize(ss["Burger_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_17 = function() {
	this.initialize(ss["Burger_atlas_3"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_16 = function() {
	this.initialize(ss["Burger_atlas_3"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tomato = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(105,131,151,0)").ss(11,1,1).p("ABhBzQgpAjg4AAQg9AAgsgsQgsgsAAg+QAAg9AsgsQAsgsA9AAQA/AAArAsQAsAsAAA9QAAA+gsAs");
	this.shape.setTransform(15,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF4244").s().p("AhYBYQgkgkAAg0QAAgzAkglQAlgkAzAAQA0AAAkAkQAlAlAAAzQAAA0glAkQgkAmg0AAQgzAAglgmgAA+ATQgGACgHAIIgPAPQgJAIgJAFIgJAGQgFAEAAAEQgCAGAGAGQAFADAIACQANADAUAAQAMAAAGgCQALgEAEgHQADgGAAgLQgBgPgDgOQgCgKgFgDQgDgCgEAAQgEAAgEACgAhFgnIgEADIgEADIgIAEQgEAFAAAKIAAAhQAAAPAFAHQADAFALAFQAWAKAOgDQAIgCAEgGQAFgFgBgJQgBgJgFgHIgJgKQgFgFgCgEQgDgEgGgPQgEgNgGgEQgEgEgDAAIgDAAgAAAhZQgJAAgHAEQgHAGgDAMIgBAJIgCAAQgHAEABAFQAAAGAHADQADACAIgBQAYABANADIAMAEQAJAMANAHIACAEIAEAFQADADADAAQAEABADgBQAEgBABgFQAHgBAEgFQAEgGgCgJQgCgIgGgGQgLgPgYgQQgbgSgUAAIgBABg");
	this.shape_1.setTransform(14.975,14.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFCC00").s().p("AA1BHQgDAAgEgDIgBgBIAAgDIgBgDIABgEQABgDADgBQADgBACAAIAAgBQAGACACADIABAGQAAAGgEACIgEACIgCgBgAgdAsIgGgDIgBgCIAAgCIgBgDIABgEQABgDADgBQACgCADABIAAgBQAGACACADQABACAAAEQgBAFgDADQgBAAAAAAQAAABgBAAQAAAAgBAAQAAAAgBAAIgDAAgAg1AfIgGgEIgCgBIAAgDIgBgDQAAAAAAAAQAAgBAAAAQAAgBABAAQAAgBAAgBQACgDACgBQADgBACAAIAAgBQAGACACADQACADgBADQAAAGgEACQgCACgDAAIgBAAgAhCACIgGgCIgBgCIAAgCIgBgEIABgEIAEgEQACgBADABIAAgBQAGACACADQABACAAAEQgBAFgDACQgBAAAAAAQAAABgBAAQAAAAgBAAQAAAAgBAAIgDAAgABBgeQgDgBgDgCIgCgCIAAgDIgBgDQAAAAAAAAQAAgBAAAAQAAgBABAAQAAgBAAgBIAEgEQADgBACABIAAgBQAGACACACQACADgBAEQAAAFgEACQAAABgBAAQAAAAgBABQAAAAgBAAQgBAAAAAAIgCAAgAAMg0QgBAAgBgBQAAAAgBAAQAAgBAAAAQgBAAAAgBIgBgEIAAgDIAAgCQACgDACgCQADgBADAAIAAgBQAGACACADQACADgBAFQgCAFgDACIgDABQgDAAgDgCg");
	this.shape_2.setTransform(13.9813,15.2167);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#990000").s().p("AhpBqQgsgsAAg+QAAg9AsgsQAsgsA9AAQA+AAAtAsQArAsAAA9QAAA+grAsQgBAGgDACQgDABgDAAQgqAjg3AAQg9AAgsgsgAhYhZQglAlAAA0QAAA0AlAkQAkAlA0AAQA0AAAkglQAlgkAAg0QAAg0glglQgkgkg0AAQg0AAgkAkgAASBYQgHgCgFgEQgGgFABgGQABgFAFgEIAJgGQAIgEAKgIIAPgQQAHgIAFgCQAKgEAGAEQAFAEACAKQADANABAQQAAALgDAGQgFAHgKAEQgGABgMAAIgFABQgRAAgMgDgAAmA3QgCACgBADIgBADIABAEIAAACIABACQAEACADAAQADABADgCQAEgCAAgGIgBgFQgCgEgGgCIAAABIgBAAIgFABgAhGAzQgLgGgDgEQgFgHAAgQIAAghQAAgKAEgEIAIgFIAEgDIADgCQAGgCAEAFQAHAFAEANQAGAPADADQABAEAGAFIAIAKQAGAHABAJQAAAJgEAGQgEAFgIACIgIABQgMAAgQgHgAgrAcQgCABgBADIgBAEIABADIAAADIABABIAGADQAFABABgCQAEgDABgFQAAgDgBgDQgDgDgFgCIAAABIgCAAIgEABgAhDAPQgCABgCACQAAABgBABQAAAAAAABQAAAAAAABQAAAAAAABIAAADIABACIABABIAHAEQADAAADgBQADgCABgGQABgEgCgDQgCgCgGgCIAAABIgBgBIgEACgAhQgNIgDAEIgBADIABAEIAAACIABABIAGADQAEABACgCQAEgCABgFQAAgDgBgDQgCgDgGgCIAAABIgDAAIgDABgABCAAQgDgBgDgCIgFgGIgCgDQgNgIgIgLIgMgFQgNgDgYAAQgIAAgDgBQgHgDgBgGQAAgGAHgDIACgBIAAgIQAEgNAHgFQAGgFAKAAQAUAAAbASQAYAPAMAPQAFAHACAIQACAJgDAGQgFAEgGABQgBAFgEACIgEAAIgDAAgAAzguIgEADQAAABgBABQAAAAAAABQAAAAAAABQAAAAAAABIAAACIABADIACACQADACACABQAFABACgCQAEgCAAgGQABgEgCgDQgCgCgGgCIAAABIgCAAIgDABgAABhCQgBABgCADIAAACIAAAEIABADQAAABAAAAQABABAAAAQAAAAAAAAQABABAAAAQAGADAEgCQADgCACgEQABgFgCgDQgDgEgFgCIAAACIgCgBIgEACg");
	this.shape_3.setTransform(15,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Tomato, new cjs.Rectangle(-5.5,-5.5,41,41), null);


(lib.ss = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAWJGQgFgEgBgGIAAgBQgGgFAAgHQABgFAEgHIAkg9QALgTABgKIABgXIAEgYQACgJAAgSQAAgkgFgRQgDgJgLgVIgJgPIgEgHIgDABQhDALhGAEQh4AGhPgZQhQgahDg/Qg/g7gnhRQg1hqgEh6QgBhEARg5QAUhAArgoQAkghBAgaQAxgUBkgeQBagbArgLQBLgTA9gFQB4gLB6AdQBYAUA/AmQApAYAqAoQAcAbAuAxQAVAYALAPQARAWAIAVQANAkgDA6QgLC+hcB1Qg0BEhLAkQhMAmhNgHIAAAoQABA6gFAgQgCALgEANQgEAMgMAXQgHAPgGAKQgKARgJAKQgKAKgOALQgiAdgqAeQgPAKgGACIgJABQgIAAgGgEgAAwD5QAFABACADQAFACAGAKQAOAZAJASQAFAKACAHQADAMAAASIAAAfIAAASQABALgBAHIgGAmQgCAWgSAcIgWAjIAKgHIA1gpQAVgRAGgHIAQgUQAcgrAHgyQADgWAAglIgBg7QABgTALgDQAFgBAEADIABABQAIgDAPABQBFACBDgkQBAgiAsg8QBPhnAOijQAFg4gLgjQgKghgfgjQgHgIgygxIgsgtQgagZgWgOQglgZhPgWQhogchGgFQhmgHiDAiQgoAKi+A9Ig6AUQggANgWAQQgmAbgYAuQgWArgGAzQgJBUAjBsQA9C7B6BIQBOAuB0AEQAsABA5gFQAZgCBKgJIAIAAQAHAAAFACg");
	this.shape.setTransform(60.7562,58.635);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ss, new cjs.Rectangle(0,0,121.5,117.3), null);


(lib.ServeBtn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_15();
	this.instance.setTransform(5.75,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_14();
	this.instance_1.setTransform(-0.5,5.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,0,72,32.5);


(lib.Response = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.responsetxt = new cjs.Text("", "bold 13px 'Bai Jamjuree'");
	this.responsetxt.name = "responsetxt";
	this.responsetxt.lineHeight = 18;
	this.responsetxt.lineWidth = 89;
	this.responsetxt.parent = this;
	this.responsetxt.setTransform(22.8,24.2);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AA+LlQgPgFgEgIQgIgPAZgYQA6g3AYhRQAYhQgShOQgLgrgVgSQgRgOgcgEQgRgCgiACQh3AEh1gYQijgghUhQQgvgtgohNQhRigAKieQAFhVAhhMQAihPA7g5QBEhBBsgpQBOgdB9gXQDDglCKAAQBJABCRANQAeADARAEQAZAGARANQAeAXARA/QAjB+AJCbQAHB4gICmQgEBfgJA8QgNBVgbBBQgUAtghA0QgVAggsA7QhfCDg+BFQg2A+gvAZQgfARggAFQgLACgLAAQgXAAgUgIgABMEUQAwAGAbAZQAcAaALA4QAQBSgWBUQgXBUg3BAQA3gCA2gtQAkgeAwhAIB8ilQAqg4ASgeQA8hgAThtQAHgiAGhFQANingHiLQgIijgkiMQgGgYgHgOQgJgTgOgLQgVgQgugEQlVgilLBZQhWAXgxAbQhOArg1BNQg0BLgRBaQgRBXARBcQAPBYArBQQAtBUA7AuQAtAjBPAbQCJAtCNgFIApAAQAfAAANABg");
	this.shape.setTransform(62.3337,74.8556);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.responsetxt}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,124.7,149.7);


(lib.Pickle = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#66CC00").s().p("AhUCWIgLAAIgLgCIgKgFIgKgGIgIgFIgIgGQgGgGgBgJQgCgQAKgPQALgPAQgEQAdgHAbgYQALgJALgNIAVgXQANgRAFgJQAKgQAEgNIADgPQABgJACgFQAEgMAMgOQAKgMAIgFQANgHAQAAQAQABANAHQAQAJAKAPQAJAPAAARIgDAPIgDAPIgDATIgEATQgFAVgNAWQgMATgSAVIgQASIgQATIgUAXQgMANgNAFQgJAEgNABIgYABgABAiNQgKAFgKAKQgLAMgGAQIgEASIgFARQgEAMgIAMIgPAWQgZAegQAPQgZAYgaAJIgRAGQgKAEgFAFQgGAFgDAIQgDAHAAAJQgBAKAEAGIAGAFIAHAFIANAIQAIAEAHACIAMABIAMABIAhAAQAZAAAOgDQAUgDAMgKIAKgKIAJgLIAhgmQAVgYAKgQQAIgLAGgOQAJgTADgOIABgMIACgNIAEgPQACgKAAgGQACgTgMgSQgNgRgUgGQgKgDgJAAQgKAAgJAEg");
	this.shape.setTransform(15.0022,14.9984);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#006600").s().p("AhNB/IgCgDIAAgEQABAAAAgBQAAAAAAgBQABAAAAAAQAAgBABAAQAAAAABgBQAAAAABAAQAAAAABAAQAAAAABAAIAEABQAAAAABABQAAAAABABQAAAAAAABQAAAAAAAAIAAAFQAAAAAAAAQgBABAAAAQAAABgBAAQAAAAgBAAIgEABIgEgBgAhxB4QgDAAgCgCQAAgBAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBIABgCIACgCQABgBAAAAQABAAABAAQAAgBABAAQAAAAABABQABAAAAAAQABAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAAAABABQAAAAAAABQAAAAAAAAIAAAEIgEADIgDABIgBAAgAAOB2QgBgBAAAAQAAgBgBAAQAAgBAAAAQAAgBgBAAIAAgEIADgCQABgBAAAAQABAAAAgBQAAAAABAAQAAAAABAAQABAAAAAAQABAAAAAAQABABAAAAQABAAAAABIACACIAAAFIgCADIgFABQAAAAgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAgAgiB2IgDgBQgBgBAAAAQAAgBgBAAQAAgBAAAAQAAgBgBAAIAAgEIADgDIAEgBQABAAAAAAQABAAAAAAQABABAAAAQABAAAAABQAAAAABAAQAAAAABABQAAAAAAABQAAAAAAAAIAAAFIgCADIgDABIgCAAgAhQBeQgBAAAAAAQgBAAAAAAQAAgBgBAAQAAAAgBgBIAAgEIACgEQAAAAABgBQAAAAABAAQABAAAAAAQABgBAAAAIAEABIACADIABAEIgBADIgEACIgBAAIgDgBgAgCBHIgCgDQAAgBAAAAQgBgBAAAAQAAgBABAAQAAgBAAAAQAAAAAAgBQAAAAABgBQAAAAABAAQAAgBAAAAIADgBIAEABIADADIgBAEQAAAAAAABQAAAAAAABQgBAAAAABQgBAAAAABIgEABQgBgBAAAAQAAAAAAAAQgBAAAAAAQgBgBAAAAgAAsBGQgBAAAAgBQgBAAgBAAQAAAAAAgBQgBAAAAgBIgCgDIAAgBIACgDIACgCQACgBADAAQABABABAAQAAAAABAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAABQABAAAAABQAAABgBAAQAAAEgDABIgEABIgBAAgAg7A6IgCgDIAAgDIACgDQAAAAAAgBQABAAAAAAQABAAAAAAQAAgBABAAIABAAIAEABQABAAAAABQABAAAAABQAAAAABABQAAAAAAABIAAADQAAABAAAAQgBABAAAAQAAABgBAAQAAAAgBAAIgEACIgEgCgAAKAUIgDgDQAAgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAABAAQAAgBAAAAIAEgBIAEABIACADQABABAAABQAAAAAAABQAAAAAAABQAAAAgBABIgCACIgEABQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBgBAAAAgAA6ATQgBAAAAgBQAAAAgBgBQAAAAAAgBQAAAAgBAAIAAgEIADgDIAEgBQABAAAAAAQABAAAAAAQABAAAAAAQABABAAAAIACADIAAAEIgCADIgEABIgEgBgAAWgUQgDgBgBgDQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAgBQAAAAAAgBQABAAAAgBQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAIABgBQABAAAAABQABAAAAAAQABAAAAABQABAAAAAAQABABAAAAQABABAAAAQAAABABAAQAAAAAAABIgBAEQAAABgBAAQAAABAAAAQgBABAAAAQgBAAgBABIgCAAIgCAAgABagyIgCgDIAAgCIABgEIADgCIACAAIAAAAIAEAAIACACIACAEIgBADIgCACIgDACIgBAAQgBAAAAAAQgBAAgBAAQAAgBgBAAQAAAAgBgBgAA1g0QAAAAgBAAQAAAAgBAAQAAgBgBAAQAAgBgBAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQABAAAAgBQABAAAAAAQABAAAAAAIABAAIAFACQAAAAABAAQAAABABAAQAAABAAAAQAAABAAAAIgBAFQAAAAAAABQgBAAAAABQAAAAgBAAQAAAAgBAAIgCABIgDgBgABuhVIgDgDIAAgDIACgEIAEgCIAAAAIAEABQAAABABAAQAAAAABABQAAAAAAABQAAAAAAABQABAAAAAAQAAABAAAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABgBAAIgDACIgCAAIgDgBgABTh0QgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBgBAAIAAgEIACgCQABgBAAAAQAAAAABgBQAAAAAAAAQABAAAAAAIACAAIAEABQAAAAABAAQAAABABAAQAAABAAAAQAAABAAAAIAAAEIgCADIgEABIgEgBg");
	this.shape_1.setTransform(15.0083,14.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#669900").s().p("AhNCSIgMAAIgMgCQgHgBgHgEIgOgIIgHgFIgFgFQgEgGAAgKQABgJACgHQADgIAGgFQAFgGAKgDIARgGQAbgJAZgYQAPgPAZgfIAQgVQAIgNAEgLIAEgSIAFgRQAFgQAMgNQAJgKAKgEQAJgEAKAAQAKAAAKACQAUAHAMARQANASgCATQAAAGgDAKIgEAOIgBAOIgCAMQgCAOgJATQgHANgHAMQgLAQgUAXIgiAmIgIAMIgKAKQgNAJgUAEQgNACgZAAgAhMBzQAAAAgBABQAAAAAAAAQgBABAAAAQAAABAAAAIAAAEIACADIAEABIAEgBQAAAAABAAQAAAAAAgBQABAAAAgBQAAAAAAAAIABgFQAAAAgBAAQAAgBAAAAQgBgBAAAAQAAgBgBAAIgEgBIgBAAIgDABgAhzBrIgDACIgBACQAAABAAAAQAAABABAAQAAABAAAAQAAABABABQACACACAAIAFgBIADgDIAAgEQAAAAAAAAQAAgBAAAAQAAgBgBAAQAAAAAAgBQgBAAAAAAQgBgBAAAAQgBAAAAAAQgBAAgBAAIgBgBIgDACgAAPBqIgDACIAAAEQAAAAAAABQAAAAABABQAAAAAAABQABAAAAABQABAAAAAAQAAAAABABQAAAAABAAQAAAAABAAIAEgBIADgDIAAgFIgDgCQAAgBgBAAQAAAAgBgBQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAABgBAAQAAAAAAABgAglBoIgCADIAAAEQAAAAAAABQAAAAABABQAAAAAAABQABAAAAABIAEABQAAAAABAAQAAAAABAAQABgBAAAAQABAAAAAAIADgDIAAgFQAAAAgBAAQAAgBAAAAQgBgBAAAAQAAAAgBAAQAAgBgBAAQAAAAgBgBQAAAAgBAAQAAAAgBAAIgEABgAhSBSIgCAEIABAEQAAABAAAAQABAAAAABQABAAAAAAQABAAAAAAQABABAAAAQABAAAAAAQABAAAAAAQABAAABAAIADgCIACgDIgBgEIgDgDIgDgBQgBAAgBABQAAAAgBAAQAAAAgBAAQAAABgBAAgAgBA7QgBAAAAABQgBAAAAAAQAAABgBAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABIACADQABAAAAABQAAAAABAAQAAAAAAAAQABAAAAABIAEgBQABgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAIAAgEIgCgDIgEgBIgDABgAArA4IgDACIgBADIAAABIABADQAAABABAAQAAABABAAQAAAAABAAQAAABABAAQADAAADgBQADgBAAgEQAAAAAAgBQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBgBAAAAQgBAAAAgBQgBAAAAAAQgBAAAAgBIgCAAIgDABgAg4AtQAAAAgBABQAAAAgBAAQAAAAAAAAQgBABAAAAIgCADIAAADIADADIAEACIAEgCQAAAAABAAQAAAAAAgBQABAAAAgBQAAAAAAgBIAAgDQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBgBAAAAIgEgBIgCAAgAALAIQgBAAAAABQgBAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAQAAAAAAABQgBAAAAABQABAAAAABIACADQABAAAAABQAAAAABAAQAAAAABAAQABAAAAAAIAEgBIADgCQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBIgCgDIgEgBIgEABgAA7AHIgDADIAAAEQAAAAAAAAQAAABABAAQAAABAAAAQABABAAAAIAEABIAEgBIADgDIAAgEIgDgDQAAAAgBgBQAAAAgBAAQAAAAgBAAQAAAAgBAAIgDABgAATgiQAAABgBAAQAAABAAAAQAAABAAABQAAAAAAABQAAAAgBABQAAAAABABQAAAAAAABQAAAAAAAAQACADACABQABAAAAAAQABAAABAAQAAAAABAAQAAAAABAAQAAgBABAAQAAAAABgBQAAAAABgBQAAAAAAgBIABgEQAAgBAAAAQAAAAgBgBQAAAAAAgBQgBAAAAgBQgBAAAAAAQgBgBAAAAQgBAAgBAAQAAgBgBAAIgBABIgBAAIgDABgABZg9IgBAEIABACIACADQACACADAAIAEgCIACgCIAAgDIgBgEIgDgCIgDAAIgBAAIgCAAIgDACgAA3hCQgBAAAAAAQgBAAAAAAQgBABAAAAQgBAAAAABQgBAAAAABQAAAAAAABQgBAAAAABQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAABQABAAAAABQABAAAAAAQABAAABAAQAAABABAAQAAAAABAAQABAAAAAAQABAAAAgBQABAAAAAAQABAAAAAAQABgBAAAAQAAgBABAAIABgFQAAAAgBgBQAAAAAAgBQgBAAAAgBQAAAAgBAAIgEgCIgBAAgABthhIgCAEIABADIADADQAAABABAAQAAAAABAAQAAAAABAAQABAAAAAAIAEgCQAAAAAAgBQABAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBgBAAQAAgBAAAAQgBgBAAAAQAAAAgBgBIgDgBIgBAAIgEACgABViBQAAAAgBAAQAAAAAAAAQgBABAAAAQAAAAAAABIgCACIAAAEQAAAAAAABQAAAAABABQAAAAAAAAQABABAAAAIAEABIAEgBIADgDIAAgEQAAAAgBgBQAAAAAAgBQgBAAAAgBQAAAAgBAAIgEgBIgCAAg");
	this.shape_2.setTransform(14.986,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,30,30);


(lib.Patty = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_4();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,30,30);


(lib.nextbtn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_10();
	this.instance.setTransform(11.35,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_9();
	this.instance_1.setTransform(-0.5,0.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.nextbtn, new cjs.Rectangle(-0.5,0,103,45), null);


(lib.Lettuce = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(105,131,151,0)").ss(11,1,1).p("AgsAJQgCgDAAgFQAAgQAOgLQAJgHALgDAgEglQADAAABAAQALAAAIAEAAZggQAEADAEADQAEAEADAEAAsgMQABACABACAAvAAQAAAAAAABQAAAPgOAMQgGAEgGADAgIAmQgOgCgKgIQgGgFgDgG");
	this.shape.setTransform(6.075,25.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#66FF66").s().p("AhKBWQAAgBgBAAQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQABAAAAAAQAAgBABAAQABAAAAAAIAFgBQAJgBAKgGIABAAIgCgDIgDgHIgEgHIgCgEIAAgCIACgBIADAAIACACIABAAIADAFIAHAMIAFgEIALgKIAEgEIAAAAIAAgBIgCgCIgIgJIgCgEQAAAAAAgBQAAAAAAAAQAAgBABAAQAAAAAAgBIACgBIADABIAEADIACADIACADIADAFIALgNIAGgJIAAgBIgBgCIgEgEIgEgDQgBgBAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAIAAgCIABgBQABAAABgBQAAAAABAAQAAABABAAQAAAAABAAIADADIAHAIIAHgLIAHgNIAAAAIgBAAQgCAAgCgDQgJgLgKgJIgDgDIAAgCIABgCIADAAIADABIAHAHIANANIACADIAEgIIAIgTIgCgBQgHgGgIgIIgMgQQgDgDACgCIACgBIACAAQACABACACIALAPQAHAIAHAEIADgGIADgIIACgJIAAgFIAAgFIACgEQAAAAABAAQAAgBABAAQAAAAABAAQAAAAAAAAQADABAAAEQAAAKgEAOIgFAMIACAAIAIgCIAHgCIAGgEIADgBIACgCIADAAIACABQAAABAAAAQAAABAAAAQAAABgBABQAAAAgBABIgHAFIgFACIgGACIgDACIgDABIgEAAIgEAAIgBAAIgHAPIgFAMQAKAAAJgFIACgBIADgBIADAAIACACQABAAAAABQAAAAgBAAQAAABAAAAQAAAAgBABIgDACQgJAFgIABIgMABIgCAEIgKARIAHAAQABAAAAAAQABAAABABQAAAAABAAQAAAAAAAAQABABAAAAQABAAAAAAQAAABAAAAQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBAAAAAAIgEABIgMAAIgHAJIgJAMIAQABIADgBIABgBIACAAQAAAAAAgBQABAAAAAAQAAAAABAAQAAAAAAAAIACACQABAAAAABQAAAAAAABQAAAAAAABQgBAAAAABQgCACgFABIgHAAIgSgBIgIAIIgLAKIgEAEIABAAIAEAAIABABIABABIABAAIACAAIAEACIABACIAAACQAAAAAAAAQgBABAAAAQAAAAAAAAQgBAAAAAAIgFAAIgBAAIgDgBIgBgBIgBgBIAAAAIgFAAIgDAAIgCgBIgGADQgKAFgIABIgGgBg");
	this.shape_1.setTransform(13.7607,16.8188);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00CC66").s().p("AhtCNIgOAAQgGgBgFgDQgFgEgCgFIALgKQAOgNALgQQAHgMAFgNQAFgKACgLQAGgXgBgZQgBgYgIgYQADgDAEgBQADgDAFAAQgCADACADQACACADABQADAAADgCQADgCgBgCQADAAAAAFQAAAFACACQACACADgBQADgCADgCQAGgGAEgIQAEgHABgJQAAAAABAAQAAAAABAAQAAAAABAAQAAABABAAIAEADQABAAABAAQABAAAAgBQABAAAAAAQABgBAAgBQABgCAAgDIABgGQABgCADAAQACABADgBIAEgEIACgEIABgGQAAgCACgCQADgCACABIAEACQABAAABABQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABgBAAAAQABgBAAAAQAAgBAAAAIADgLQACgGAGgBIAEAAIAEgBQAEgBADgFQAEgGADgBQACAFAEAEQAFAFAGABQgCADgBAFIAAAIQAAAKAGACQAAAAgBABQAAAAAAABQAAAAAAABQABAAAAABIADAEIAGABIAEADIABAEIAAAEIACAEQAAAAABAAQAAABABAAQAAAAABAAQAAAAABAAIABAAIACgBIACAAIABACQgCACACAFQABADAEACQAGAFALAAQAFAAADgBQAAgBABAAQAAAAABAAQAAgBAAAAQAAAAAAgBIAAgDQAAAAABAAQAAAAABAAQAAAAABAAQAAABABAAIADAEQAEAIABAFQABAGgCAGIgGAKQgEAGABAEQAAAAgBgBQAAAAgBAAQAAAAgBAAQgBAAgBAAIgFACIgDADIgFACIgEABIgDABIgBADIgBACQABALgHAJQAAAAAAgBQgBAAAAAAQgBAAAAAAQgBAAgBAAQAAABgBAAQAAAAgBAAQAAABgBAAQAAAAgBABIgBAEIgCACIgDADIgDACIgDAEIgBAGIgCATQAAABAAAAQAAABAAAAQgBABAAAAQgBAAAAAAQAAABgBAAQAAAAgBgBQAAAAAAAAQgBAAAAgBIgDgDQgDgCgEADIgHAEQgDACgLABQgJABgDADQgBADAAAEIACAGIAAAGQAAADgDACIgFACQAAABAAAAQgBABAAAAQAAAAAAABQAAAAAAABQgFAAgDADQgDADgBADQgCgCgEABQgDACgCADIgBAHQgBADgCACQgEAEgHAAIgKgCIgEgBIgEgBIgFABIgFACQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAIgDgCQgDABgDADIgBADIgDACQgCABgEgBIgBAAQAGgDAGgEQAOgLAAgQIAAgBIAAABQAAAQgOALQgGAEgGADIgHgBQgIgDgJADQgDABgCACIgBACQgOgDgKgIQgGgEgDgHQADAHAGAEQAKAIAOADIAAACQgEgCgIABgAhHBFIAAACIACADIAEAHIADAHIACADIgBAAQgKAHgJAAIgFABQAAAAgBAAQAAABgBAAQAAAAgBABQAAAAAAAAQAAABAAAAQAAABAAAAQABABAAAAQABABAAAAIAGABQAIgBAKgFIAGgDIACABIADAAIAFAAIAAABIABAAIABABIADABIABAAIAFAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAgBAAAAIAAgCIgBgBIgEgCIgCAAIgBAAIgBgCIgCgEIACAEIgBgBIgEAAIgBAAIAEgDIALgKIAIgIIATABIAGAAQAFgCACgCQAAgBABAAQAAAAAAgBQAAAAAAgBQAAAAgBgBIgCgCQAAAAAAAAQgBAAAAAAQAAAAgBABQAAAAAAAAIgCAAIgBABIgCABIgRgBIAKgLIAHgKIALAAIAEAAQAAgBABAAQAAAAAAgBQABAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAgBgBAAQAAAAgBgBQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBgBgBAAIgHAAIAKgSIACgEIAMAAQAIgCAJgEIADgDQABAAAAgBQAAAAAAAAQABgBAAAAQAAgBgBAAIgCgCIgDAAIgDABIgCABQgJAGgKAAIAFgMIAHgPIABAAIAEAAIAEAAIADgBIADgBIAGgDIAFgCIAHgFQABgBABAAQAAgBAAAAQAAgBAAAAQAAgBAAgBIgCAAIgDAAIgCABIgDABIgGAEIgHADIgIABIgCAAIAFgLQAEgOAAgLQAAgDgDgBQAAgBAAAAQgBAAAAABQgBAAAAAAQgBAAAAABIgCADIAAAFIAAAFIgCAJIgDAIIgDAHQgHgFgHgIIgLgOQgBgDgCgBIgCAAIgCABQgCACADADIALAQQAIAIAHAGIACACIgIATIgEAHIgCgEIgMgMIgIgGIgDgCIgDAAIgBACIAAACIADADQALAKAIAJQACADACAAIABAAIAAAAIgHAPIgGAKIgIgIIgDgCQgBgBAAAAQgBAAAAAAQgBAAAAAAQgBAAgBAAIgBACIAAABQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAIAEAEIAEADIACACIAAABIgHAJIgLANIgDgFIgCgDIgCgCIgEgDIgDgCIgCACQAAAAAAAAQgBAAAAABQAAAAAAABQAAAAAAABIACADIAIAJIACADIAAAAIAAABIgEADIgLAKIgHgHIgIgGIgBAAIgCgCIgDAAQgIgDgLgBIgFABIAFgBQALABAIADIgCACgAg8BKIgDgFIAIAGIAHAHIgFAFgAg/BFIAAAAgAhFBDIAAAAg");
	this.shape_2.setTransform(14.9531,14.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#169976").s().p("AhmCVIgGgDQABAAAAAAQAAABAAAAQgBAAAAABQAAAAgBABIgFABQgNgBgLgGQgKgFgBgHQgBgEAEgFIAIgIIAEgEQAPgOAKgRIAIgPQAFgMADgOQAJgngNgsIgBgGQgBgEACgCQABgDAFgDQAGgEAGAAQADgBAEACQADABABACQADgCADAAQAEAAACACQADABABADQABACgBADQAGgDADgKIAFgOQACgDAEgBQADgCADACQAAgFAFgFQAFgEAGgBQgBgHAHgGQAGgFAJABQAAgIAIgGQAHgGAKABQADgHAEgDQADgCAEgBQAEAAADACIAEAFQABAFACABIAFACIAFADQADADgCAHQgDAJABADIACAFIAEAEIATARQAKAJgEAGQACADAFABQAFACADgCIAEgDIADgCQAEgCAFACQAEACACADQACADABAEIACAHIADAHQABAEAAADIgEAIIgFAGIgCAGIgBAGQgCADgDABQgEACgDgCQgCADgEACQgEABgEAAQACAIgIALQgIAMgMAIIgCATIgCAHQgBAEgDACQgDACgFAAQgFgBgDgDQgGAEgHACQgHACgHAAIAAAWQgBAEgBABIgDACIgDgBQgBACgDACQgDACgDgBQgBAFgFACQgFADgFgBQACAFgCAEQgCAFgFACQgIAEgOAAIgLgBIgMgBQgEAFgJABQgIAAgGgEQgFADgHAAQACACgCADQgCADgDAAQgEAAgDgBgAhiCNIAAgCIACgCQABgCAEAAQAIgDAJACIAGACIABAAQAEABADgCIACgCIACgDQACgDADAAIADABQABAAAAABQAAAAAAAAQAAABAAAAQAAAAgBABIAFgCIAGAAIADAAIAEABIAKACQAIAAADgDQADgCAAgEIACgHQABgDADgCQAEgBADACQAAgDADgDQAEgDAEAAQAAgBAAAAQAAgBABAAQAAAAAAgBQAAAAABAAIAEgDQADgBABgEIgBgGIgBgGQgBgEACgCQACgEAJgBQALgBADgCIAHgEQAEgCADACIADACQABABAAAAQABAAAAAAQAAABABAAQAAAAAAAAQABgBAAAAQABAAAAgBQAAAAABgBQAAAAAAgBIACgTIAAgFIADgFIADgCIADgCIACgDIACgEQAAAAABgBQAAAAABgBQAAAAABAAQAAAAABAAQABgBAAAAQABAAAAAAQABAAAAAAQABABAAAAQAGgJAAgLIAAgCIACgDIADgBIAEgBIAEgCIAEgDIAFgCQABAAAAAAQABAAABAAQAAAAABAAQAAABAAAAQgBgEAEgGIAGgKQADgFgCgHQgBgFgEgIIgDgEQAAAAgBgBQAAAAgBAAQAAAAgBAAQAAAAgBAAIABADQAAABAAAAQgBAAAAABQAAAAgBAAQAAAAgBABQgCABgGAAQgLAAgGgEQgDgCgCgEQgBgEACgDIgBgCIgCAAIgCABIgCAAQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAAAgBAAIgCgEIAAgEIgBgEIgEgDIgFgBIgEgEQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQgGgCAAgKIABgIQAAgFADgDQgHgBgEgEQgFgEgBgGQgEABgDAGQgEAFgDABIgFABIgEAAQgFABgCAGIgDALQAAAAgBABQAAAAAAABQgBAAAAABQgBAAAAAAQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAgBgBAAIgEgCQgDAAgDABQgBACgBADIgBAFIgBAEIgEAEQgEABgCgBQgDAAgBADIgBAFQABADgCADQAAAAAAABQgBAAAAAAQgBABgBAAQAAAAgBAAIgFgDQAAAAgBgBQAAAAgBAAQAAAAgBAAQAAAAgBABQAAAIgEAIQgEAHgHAGQgCADgDABQgEABgCgCQgCgBAAgGQAAgFgDAAQABACgDADQgCACgEgBQgDgBgBgCQgCgDABgDQgEABgEACQgEABgCADQAHAZABAXQACAZgGAXQgDALgEAKQgFANgIAMQgKAQgPAOIgKAJQABAFAFAEQAFAEAHAAIANAAQAIgBAEACIAAAAg");
	this.shape_3.setTransform(15.0035,14.995);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.1,0,34.1,34.4);


(lib.item4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.267)").s().p("AiVCWIAAkrIErAAIAAErg");
	this.shape.setTransform(15,15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.item4, new cjs.Rectangle(0,0,30,30), null);


(lib.item3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.267)").s().p("AiVCWIAAkrIErAAIAAErg");
	this.shape.setTransform(15,15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.item3, new cjs.Rectangle(0,0,30,30), null);


(lib.item2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.267)").s().p("AiVCWIAAkrIErAAIAAErg");
	this.shape.setTransform(15,15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.item2, new cjs.Rectangle(0,0,30,30), null);


(lib.item1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.267)").s().p("AiVCWIAAkrIErAAIAAErg");
	this.shape.setTransform(15,15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.item1, new cjs.Rectangle(0,0,30,30), null);


(lib.door = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#169976").s().p("AlPAMIAAgXIA5AAIAHAGQALgFANACQAHABAHAEIADAAIAFgEIAFgDIGjAEIAAACIAEgBQAMgFAMACQAFABAGACIAIgBQABAAABAAQABAAAAAAQABgBAAAAQAAAAAAgBQAPABAMAJIAAABIAEgIIA3AAIAAARg");
	this.shape.setTransform(33.55,86.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFA8D").s().p("AgEAiQgKgBgJgIQgFgGgCgFQgDgIABgJQACgLAFgGQAJgLARAAIAAgCQAOADAIAHQAIAHACALQACALgEAJQgFAKgKAFQgIAEgIAAIgEAAg");
	this.shape_1.setTransform(49.5335,46.2411);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4B352A").s().p("AEZGzQgMgKgPgBQAAAAAAAAQAAABgBAAQAAAAgBAAQgBABgBAAIgJABQgFgDgFgBQgMgCgMAFIgEACIAAgDImkgEIgEAEIgFADIgDABQgHgEgHgCQgNgCgLAFIgHgFQgQgRAAgqIAArTQAAg1AYgPQANgHASADIAgAHQAcAGBAABIFBACQA0AAARAXQAHAKABARQABALgDAUQgIBLABCYQACD8AICNIADA5QABAggCAYQgCARgDAMIgEAJIAAAAgACkgDQgSAAgJAJQgFAGgCALQgBALAEAIQACAFAFAGQAIAHALACQAKABAKgFQAKgFAFgKQAFgKgDgLQgCgMgIgHQgHgFgPgEg");
	this.shape_2.setTransform(33.1667,43.4921);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,67.1,88);


(lib.customer = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhjGUQgGgCAAgFQAAgDAEgGQAMgSAdgjIAggnIAIgHIgBjaIgEAAQgEgBgJgFQhCgrgogoQgJgJADgHQAEgHAJADQAGACAGAHQAtAtA3AgQABgCADgBIABi8IgIgBQgngDgRgIQgYgMgRgZQgSgcgDghQgEgiAMgeQAMgfAagWQAagWAfgIQAQgEAVAAIAjAAQAZABAMAFQAOAFASATQAUAUAHAMQALAUABAkQADBWguAjQgXASgkAEQgOABgVAAIAAABIgBCzQAZgJAmgaQAxgfAZgIQAKgCADADQAGAGgGAHQgDAFgIADQgXAJgKAFQgKAEgOAKIgWAQQgdAUgfAJIAAABIABDoQAGAAAKAJIApAmQAZAUAVALIAMAIQAFAGgDAHQgFAHgOgFQgOgGgUgQQgfgZgXgXQgJgJgFgCQgDAEgGgBIAAAAQgjAjgbApQgIALgGADIgFABIgFgCgAAOmAIghACQgOABgXALQghAPgMAOQgLANgHAXQgMApAKAiQAFATAMAOQANAQARAHQAPAHAmACQAvABAUgFQAngIARgcQAOgXgBgtQAAgcgDgOQgEgQgJgMQgNgVgqgbQgKAHgUAAgAAAjRQgJAAgFgCQgEgBgRgKQgKgEgBgFQgBgEADgDQADgEAEgBQAGgBAKAFQALAGAEABIALABIAdAAIAHgBQADgBAGgHQAFgGAFAAQAGABABAHQAAAFgCAGQgFAMgHAEQgEACgNAAgAgfkhQgJgCgFgHQgFgGAAgJQAAgJAFgGQAEgFAFgCQAFgCAEABQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAAAgBQAIABAHAFQAGAGACAIQACAIgEAIQgEAHgHAEQgGACgFAAIgFAAgAAwkiQgJgCgFgGQgFgHAAgJQAAgIAFgHQAEgFAFgCQAFgBAEAAQAAAAABAAQAAAAABAAQAAAAAAgBQAAAAAAAAQAIAAAHAGQAGAFACAIQACAIgEAIQgEAIgHADQgGADgFAAIgFgBg");
	this.shape.setTransform(15.1765,40.5819);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.customer, new cjs.Rectangle(0,0,30.4,81.2), null);


(lib.Cheese = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(105,131,151,0)").ss(8.5,1,1).p("AARAAQAAAHgFAGQgFAFgHAAQgGAAgFgFQgFgGAAgHQAAgHAFgFQAFgGAGAAQAHAAAFAGQAFAFAAAHg");
	this.shape.setTransform(15.05,20.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(105,131,151,0)").ss(10.5,1,1).p("AAVAAQAAAJgHAHQgGAHgIAAQgIAAgGgHQgGgHAAgJQAAgIAGgHQAGgHAIAAQAIAAAGAHQAHAHAAAIg");
	this.shape_1.setTransform(8.3,11.975);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("rgba(105,131,151,0)").ss(8.3,1,1).p("AARAAQAAAHgFAGQgFAFgHAAQgGAAgFgFQgFgGAAgHQAAgHAFgFQAFgFAGAAQAHAAAFAFQAFAFAAAHg");
	this.shape_2.setTransform(23.375,24.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("rgba(105,131,151,0)").ss(11,1,1).p("ABjgcQAAARgLALQgMAMgPAAQgPAAgMgMQgKgLAAgRQAAgSAKgMQAMgMAPAAQAPAAAMAMQALAMAAASgAAkhcQAAAOgJAKQgJAKgMAAQgNAAgJgKQgJgKAAgOQAAgOAJgKQAJgJANAAQAMAAAJAJQAJAKAAAOgAgeBSQAAAOgKAKQgJALgOAAQgNAAgKgLQgJgKAAgOQAAgPAJgKQAKgLANAAQAOAAAJALQAKAKAAAPgAiViAID8gVIAvErIkmAAg");
	this.shape_3.setTransform(15,15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FCB454").s().p("AiQCWIgFkVID8gWIAvErgAiLh0IAGD8IEHgBIgpkNg");
	this.shape_4.setTransform(15,15);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF9B17").s().p("AhYBvQgJgKAAgOQAAgPAJgKQAKgLANAAQAOAAAJALQAKAKAAAPQAAAOgKAKQgJALgOAAQgNAAgKgLgABGBwQgFgFAAgIQAAgHAFgGQAFgFAHAAQAHAAAEAFQAFAGAAAHQAAAIgFAFQgEAGgHgBQgHABgFgGgAgNBGQgFgGAAgIQAAgHAFgGQAFgFAHAAQAGAAAFAFQAFAGAAAHQAAAIgFAGQgFAFgGAAQgHAAgFgFgAAgAFQgLgLAAgSQAAgRALgMQALgMAQAAQAPAAALAMQAMAMAAARQAAASgMALQgLAMgPAAQgQAAgLgMgAhTgJQgGgGAAgKQAAgJAGgGQAGgIAJABQAIgBAGAIQAHAGAAAJQAAAKgHAGQgGAHgIAAQgJAAgGgHgAgSg/QgJgLAAgNQAAgOAJgKQAJgJAMAAQANAAAJAJQAJAKAAAOQAAANgJALQgJAKgNgBQgMABgJgKg");
	this.shape_5.setTransform(15.225,14.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFF085").s().p("AiGh0IDkgSIApENIkHABgAhQA5QgKAKAAAPQAAAOAKAKQAJALANAAQAOAAAKgLQAJgKAAgOQAAgPgJgKQgKgLgOAAQgNAAgJALgABNBRQgFAGAAAHQAAAIAFAFQAFAGAHgBQAHABAFgGQAEgFAAgIQAAgHgEgGQgFgFgHAAQgHAAgFAFgAgFAmQgFAGgBAHQABAIAFAGQAFAFAFAAQAIAAAFgFQAEgGAAgIQAAgHgEgGQgFgFgIAAQgFAAgFAFgAAng6QgKAMAAARQAAASAKALQALAMAQAAQAQAAALgMQALgLAAgSQAAgRgLgMQgLgMgQAAQgQAAgLAMgAhMgtQgGAGAAAJQAAAKAGAGQAHAHAIAAQAJAAAFgHQAHgGAAgKQAAgJgHgGQgFgIgJABQgIgBgHAIgAgLh0QgIAKgBAOQABANAIALQAKAKAMgBQAMABAJgKQAJgLAAgNQAAgOgJgKQgJgJgMAAQgMAAgKAJg");
	this.shape_6.setTransform(14.5,15.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Cheese, new cjs.Rectangle(-5.5,-5.5,41,41), null);


(lib.Bye = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_21();
	this.instance.setTransform(12.65,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_20();
	this.instance_1.setTransform(-0.5,-0.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,93,43.5);


(lib.BuildAre = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(153,51,0,0.537)").s().p("EgjtADyIAAnjMAtIAAAIaTAAIAAHjg");
	this.shape.setTransform(228.575,24.225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,457.2,48.5);


(lib.Bread = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFECDB").s().p("AhygaQAAgZgKgJIAAgMIgCgVQgBgbAQgJQAKgGAPADQAjAGAUAfIAMAUQAIAKAJAAQARACAKgaIAHgTQAFgLAGgFQAOgMAhAJQAUAEAHAIQAIAJABAYQACBogNBiIjlAOg");
	this.shape.setTransform(17.5548,18.7359);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF9149").s().p("Ah+C6IgIgBIgEABQgIABgHgGQgKgFgCgJQgBgGADgFIgBgQIgBiaQAAgLACgIQgJgJgCgWIgBg4QAAgeAIgLQAKgOAYgGQAtgLArATIATAIQAKAEAIgCQAKgCASgMQANgHATAAQAMAAAWADQAaADAPAFQAWAHALAPQAKAMAEATQACANAAAXQABBkgKBxQgCAegOAKQgJAGgSABQhmAKhoAAIgsAAgAhviAQgQAKABAbIABAVIAAAMQAKAJAAAZIABCgIDkgPQANhigBhoQgBgYgIgIQgIgJgTgEQgigIgNALQgHAFgEALIgHATQgLAagQgBQgKgBgHgKIgNgUQgTgfgjgGIgJgBQgKAAgGAEg");
	this.shape_1.setTransform(17.6262,18.5949);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,35.3,37.2);


(lib.Bacon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F89C7E").s().p("AiGBnQAAgBAAAAQAAgBAAAAQABgBAAAAQABAAAAgBIAcgOIAKgGQACgCAEgFIAHgHQAEgDAJgEIAKgDIAIAAQAFgBAEgEQADgEACgFQABgFACAAQAAAAAAAAQABABAAAAQAAAAAAABQABABAAAAQABAEgEAGQgHAKgIACIgEABIgFAAIgLADQgIAEgDADIgEAEIgEAFIgKAIIgPAHIgJAFQgGADgDAAQgBAAAAAAQgBAAAAAAQgBAAAAgBQAAAAAAAAgAikBfIgBgDIABgDQAAgCADgDQAHgJAKgFQAKgFAKAAIAJgBQAFgBADgCIACgCIACgBQAAAAAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAABQABAAAAAAQAAABAAAAQAAAAAAABIgBACQgFAFgHACIgIABIgJAAIgJAEIgJAFIgIAGQgEAEgBAFgAgsAVIABgDIAHgIIAIgKIAIgJIAIgEIAHgCIAGAAIAGABIAEACIADABQADACAEgBQAEgBADgDIAHgIIAGgJQADgDAFgCIAJgCIAJgDQAEgCACgEIADgDIABgBIACABIAAAEQgEAKgPAEIgLADQgGADgDAEIgDAFIgEAFQgDAFgFACQgGACgEgBIgEgCIgEgCQgGgCgFABQgGABgFADQgJAFgIANIgEAFQgCADgCABIgCABIgCgCgAAWADQAGgEAHgCIAHgBIAHgBIAGAAIAFgEIAFgGIACgDIACgEQABgDAFgFIAJgIIADgCIACABIAAABIAAADIgDACIgDADIgCADIgEAEIgEAEIgCADIgBADIgFAHIgJAGIgHAAIgGABQgKAAgJAHIgHAIQACgKADgDgABrgnQgBAAAAAAQAAAAAAAAQgBgBAAAAQAAAAAAAAIAAgCIABgCIAEAAQAEAAAFgEQAEgCAEgFIAIgHQAEgEAEgBQACgBAIAAQAGAAACgCIACgBIACAAQABABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAIgBADQgEADgGAAIgKAAQgFACgIAIQgJAJgEACQgEACgEAAIgEAAgABng7IgBgCQAAAAAAgBQAAAAAAgBQAAAAABAAQAAgBAAAAIAKgJQAGgFAFgDQABAAAAgBQABAAAAAAQABgBAAAAQAAAAAAgBIABgEIgBgLQAAgBAAgBQAAAAABgBQAAAAAAAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIABACIAAADIAAADIAAAIIgBAHIgDAEIgEACQgJAFgHAIIgDACIgBAAIgBAAg");
	this.shape.setTransform(20.22,14.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BD2C2E").s().p("AiTCHIgGgFIgkgdQAAgSAMgQQAKgNAQgIQALgEATgEIAfgIQAdgLAWgaIAKgMQAGgIAFgEQANgNAVgHIAogLQAagIASgRQAKgKAHgMQAHgNAEgOQAhAXAdAaQgJAXgQASQgQASgTAJIgSAGIgSAGQgUAHgQAPIgPAPQgJAIgGAEIgNAHIgKADIgWAGIgSAHIgRAJIgnAXQgWAOgOAQIgGAGQgEADgEAAIgBABIgFgCgAghAmQgCAGgEADQgEAEgEABIgIABIgKADQgKADgEADIgGAHQgEAGgDABIgKAHIgbAOQgBAAAAABQgBAAAAABQAAAAgBAAQAAABAAAAQAAABABAAQAAAAAAABQABAAAAAAQABAAAAAAQAEAAAGgDIAIgFIAQgIIAJgHIAEgFIAEgFQADgDAIgDIAMgEIAEAAIAEgBQAIgBAHgLQAEgFgBgEQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAAAgBAAQgCAAAAAEgAhlA3IgCABIgCACQgDADgFAAIgJABQgKABgKAFQgJAFgIAJQgCACgBADIgBADIACACIACAAQACgFAEgEIAIgGIAIgFIAKgDIAIgBIAIAAQAHgCAFgGIACgCQAAAAAAAAQAAgBgBAAQAAAAAAgBQAAAAgBAAIgBgBIgBAAgAgKgQIgHAFIgJAJIgIAJIgHAJIAAADIABABIACAAQADgBACgDIAEgGQAIgMAIgFQAGgEAGAAQAFgBAFACIAEABIAEACQAFACAFgCQAFgCAEgFIADgFIADgGQAEgEAGgDIAKgDQAPgEAEgKIAAgDIgBgBIgCAAIgCADQgDAEgEADIgJADIgJACQgFACgDADIgGAIIgHAJQgCACgEABQgEABgEgBIgDgCIgDgBIgHgBIgGAAIgHABgABWgoIgIAIQgGAFgBADIgCADIgCAEIgFAFIgFAEIgFABIgIAAIgHABQgHACgGAFQgDACgCAKIAHgHQAJgGAKgBIAHAAIAGgBIAJgHIAFgGIACgEIABgDIAEgEIAEgDIADgDIACgDIADgCIABgDIgBgCIgCAAIgDACgACmhJIgCAAQgDACgGAAQgHAAgCABQgEABgFAEIgHAIQgFAFgDACQgGADgEAAIgEABIgBABIABACQAAABAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAGACAGgDQAEgCAJgKQAIgIAGgBIAKAAQAGgBADgCIABgDQABgBAAAAQAAAAAAgBQAAAAgBAAQAAgBAAAAIgBAAIgBAAgACDhpQAAAAAAAAQgBABAAAAQAAABAAAAQAAABAAAAIAAALIAAAFQAAAAgBABQAAAAAAAAQgBABAAAAQgBABgBAAQgFACgFAFIgKAJQgBABAAAAQAAABAAAAQgBABAAAAQAAAAAAABIABABIACABIADgDQAIgHAIgGIAEgCIAEgDIAAgIIAAgIIAAgDIAAgCIgBgCIgBgBIgBABg");
	this.shape_1.setTransform(19.975,15.205);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#69140B").s().p("AiSCVIgFgDIgHgEIghgaIgEgDQgCgCAAgCQgCgDAAgHIAEgSQAGgQAMgMQAMgLASgHQAKgEAYgGQAWgFALgFQARgHAMgMIAMgQIANgQQAMgOAWgIQAOgFAbgGQAbgJARgPQAKgJAHgMQAHgNACgOIABgEQAAgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAgBQADgBAFADIA+AwIAGAGQADAEAAAEIgBAHIgDAGIgGAJQgKARgKALQgRATgQAIIgSAHIgTAFQgWAIgSAQIgOAOQgIAJgHAEQgGAEgKAEIgFACIgXAGQgOAEgQAJIgeAQIgTAMQgJAHgIAHIgIAJIgIAIQgJAHgHAAIgFgBgAB1hrQgHAMgKAKQgTARgZAIIgoALQgWAHgMANQgFAEgGAIIgKAMQgWAagdALIgfAIQgTAEgLAEQgQAIgKANQgMAQAAASIAkAdIAFAFQAFACACgBQAEAAAEgDIAGgGQAOgQAVgOIAogXIARgJIASgHIAWgGIAKgDIANgHQAGgEAJgIIAOgPQARgPAUgHIARgGIASgGQAUgJAQgSQAQgSAJgXQgdgaghgXQgEAOgHANg");
	this.shape_2.setTransform(20,15.0047);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,40,30);


(lib.SpeechBubble = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.speechText = new cjs.Text("", "10px 'Arial'");
	this.speechText.name = "speechText";
	this.speechText.lineHeight = 13;
	this.speechText.lineWidth = 79;
	this.speechText.parent = this;
	this.speechText.setTransform(21.4,40.25);

	this.speechBubble = new lib.ss();
	this.speechBubble.name = "speechBubble";
	this.speechBubble.setTransform(60.8,78.4,1,1,0,0,0,60.8,58.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF4244").s().p("AgbLeIAAgDIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIgBgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgGIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgIIAAgHIAAgIIAAgHIAAgHIAAgIIAAgIIAAgHIAAgIIAAgHIAAgHIAAgIIAAgIIAAgHIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgHIAAgIIAAgIIAAgHIgBgHIAAgIIAAgHIAAgIIAAgIIAAgHIAAgHIADgIIAAgHIAAgIIAAgIIAAgHIAAgHIAAgIIAAgDIA4AAIAAW7g");
	this.shape.setTransform(136.35,73.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.speechBubble},{t:this.speechText}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.SpeechBubble, new cjs.Rectangle(0,0,139.3,146.8), null);


(lib.orderBubble = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_13();
	this.instance.setTransform(45.4,14.1,0.5,0.5);

	this.i4 = new lib.item4();
	this.i4.name = "i4";
	this.i4.setTransform(37.4,158.9,1,1,0,0,0,15,15);

	this.i3 = new lib.item3();
	this.i3.name = "i3";
	this.i3.setTransform(37.4,126.9,1,1,0,0,0,15,15);

	this.i2 = new lib.item2();
	this.i2.name = "i2";
	this.i2.setTransform(37.4,94.7,1,1,0,0,0,15,15);

	this.i1 = new lib.item1();
	this.i1.name = "i1";
	this.i1.setTransform(37.4,62.15,1,1,0,0,0,15,15);

	this.a1 = new cjs.Text("", "bold 15px 'Comic Sans MS'");
	this.a1.name = "a1";
	this.a1.lineHeight = 23;
	this.a1.lineWidth = 14;
	this.a1.parent = this;
	this.a1.setTransform(97.55,49.15);

	this.a4 = new cjs.Text("", "bold 15px 'Comic Sans MS'");
	this.a4.name = "a4";
	this.a4.lineHeight = 23;
	this.a4.lineWidth = 14;
	this.a4.parent = this;
	this.a4.setTransform(97.55,151);

	this.a3 = new cjs.Text("", "bold 15px 'Comic Sans MS'");
	this.a3.name = "a3";
	this.a3.lineHeight = 23;
	this.a3.lineWidth = 14;
	this.a3.parent = this;
	this.a3.setTransform(97.55,113.9);

	this.a2 = new cjs.Text("", "bold 15px 'Comic Sans MS'");
	this.a2.name = "a2";
	this.a2.lineHeight = 23;
	this.a2.lineWidth = 14;
	this.a2.parent = this;
	this.a2.setTransform(97.55,82.25);

	this.instance_1 = new lib.CachedBmp_12();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.a2},{t:this.a3},{t:this.a4},{t:this.a1},{t:this.i1},{t:this.i2},{t:this.i3},{t:this.i4},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.orderBubble, new cjs.Rectangle(0,0,139,217), null);


// stage content:
(lib.Burger = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,41,42,43,59];
	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		
		this.doorbtn.addEventListener("click", () => {
		  this.play();
			console.log("Door clicked!");
		});
	}
	this.frame_41 = function() {
		this.stop();
		
		const messages = [
		  "Hey there! I saw your sign and would love a burger.",
		  "Hi Chef! Got any burgers cooking today?",
		  "Hello! I’m starving. Can you make me a burger?",
		  "I heard this is the best burger place in town!",
		  "Hey chef! I'm ready for the best burger of my life!"
		];
		
		const message = messages[Math.floor(Math.random() * messages.length)];
		const bubble = this.speechBubble;
		const textField = bubble.speechText;
		
		textField.text = ""; // Clear
		this.nxtbtn.visible = false; // Hide Next button
		
		let index = 0;
		
		const typingInterval = setInterval(() => {
		  textField.text += message.charAt(index);
		  index++;
		  if (index >= message.length) {
		    clearInterval(typingInterval);
		
		    this.nxtbtn.visible = true;
		  }
		}, 40);
		
		this.nxtbtn.addEventListener("click", () => {
		  this.play();
		});
	}
	this.frame_42 = function() {
		this.stop();
		
		const allIngredients = ["Cheese", "Lettuce", "Tomato", "Patty", "Pickle", "Bacon"];
		const shuffled = allIngredients.sort(() => Math.random() - 0.5);
		const selectedIngredients = ["Bread", shuffled[0], shuffled[1], shuffled[2]];
		
		const ingredientClips = [
		  new lib[selectedIngredients[0]](),
		  new lib[selectedIngredients[1]](),
		  new lib[selectedIngredients[2]](),
		  new lib[selectedIngredients[3]]()
		];
		
		const slots = [this.order.i1, this.order.i2, this.order.i3, this.order.i4];
		const amounts = [this.order.a1, this.order.a2, this.order.a3, this.order.a4];
		
		let expectedBuild = [];
		
		for (let i = 0; i < 4; i++) {
		  const icon = ingredientClips[i];
		  const scaleX = 30 / icon.nominalBounds.width;
		  const scaleY = 30 / icon.nominalBounds.height;
		  icon.scaleX = scaleX;
		  icon.scaleY = scaleY;
		  icon.x = 0;
		  icon.y = 0;
		
		  slots[i].removeAllChildren();
		  slots[i].addChild(icon);
		
		  const amount = Math.floor(Math.random() * 3) + 1;
		  amounts[i].text = amount.toString();
		
		  for (let j = 0; j < amount; j++) {
		    expectedBuild.push(selectedIngredients[i]);
		  }
		}
		
		let buildStack = [];
		
		const ingredientButtons = {
		  Bread: this.bread,
		  Tomato: this.tomato,
		  Lettuce: this.lettuce,
		  Cheese: this.cheese,
		  Patty: this.patty,
		  Pickle: this.pickle,
		  Bacon: this.bacon
		};
		
		for (let name in ingredientButtons) {
		  ingredientButtons[name].addEventListener("click", () => {
		    const icon = new lib[name]();
		    icon.scaleX = 30 / icon.nominalBounds.width;
		    icon.scaleY = 30 / icon.nominalBounds.height;
		    icon.x = buildStack.length * 35;
		    icon.y = 0;
		    this.buildArea.addChild(icon);
		    buildStack.push(name);
		  });
		}
		
		this.servebtn.addEventListener("click", () => {
		  let correct = true;
		
		  if (buildStack.length !== expectedBuild.length) {
		    correct = false;
		  } else {
		    for (let i = 0; i < expectedBuild.length; i++) {
		      if (buildStack[i] !== expectedBuild[i]) {
		        correct = false;
		        break;
		      }
		    }
		  }
		
		  for (let i = this.buildArea.numChildren - 1; i >= 0; i--) {
		    const child = this.buildArea.getChildAt(i);
		    if (!(child instanceof createjs.Shape)) {
		      this.buildArea.removeChildAt(i);
		    }
		  }
		
		  this.buildStackResult = correct;
		  buildStack = [];
		  this.play();
		});
	}
	this.frame_43 = function() {
		this.stop();
		
		this.response.responsetxt.text = this.buildStackResult
		  ? "This burger is the best I have ever had!"
		  : "This burger sucks!";
		this.btn.addEventListener("click", () => {
		  this.play();
		});
	}
	this.frame_59 = function() {
		this.stop();
		
		setTimeout(() => {
		  this.gotoAndPlay(2);
		}, 1000); // 5000 milliseconds = 5 seconds
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(41).call(this.frame_41).wait(1).call(this.frame_42).wait(1).call(this.frame_43).wait(16).call(this.frame_59).wait(1));

	// Layer_2
	this.instance = new lib.customer();
	this.instance.setTransform(545,-33.5,1,1,0,0,0,15.2,40.6);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({y:255.35},40).to({y:-40.75},18).wait(1));

	// Layer_3
	this.nxtbtn = new lib.nextbtn();
	this.nxtbtn.name = "nxtbtn";
	this.nxtbtn.setTransform(547.6,339.2,0.5882,0.5882,0,0,0,51.1,22.4);

	this.speechBubble = new lib.SpeechBubble();
	this.speechBubble.name = "speechBubble";
	this.speechBubble.setTransform(567.85,164.9,1,1,0,0,0,69.7,73.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(105,131,151,0)").ss(1,1,1).p("AnfjMIO/AAIAAGYIu/AAg");
	this.shape.setTransform(783.425,203.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AnfDMIAAmXIO/AAIAAGXg");
	this.shape_1.setTransform(783.425,203.6);

	this.instance_1 = new lib.CachedBmp_17();
	this.instance_1.setTransform(35.45,431.9,0.5,0.5);

	this.servebtn = new lib.ServeBtn();
	this.servebtn.name = "servebtn";
	this.servebtn.setTransform(546,335.3,1,1,0,0,0,35.5,16.2);
	new cjs.ButtonHelper(this.servebtn, 0, 1, 1);

	this.order = new lib.orderBubble();
	this.order.name = "order";
	this.order.setTransform(541.65,121.5,1,1,0,0,0,69.5,108.4);

	this.instance_2 = new lib.CachedBmp_16();
	this.instance_2.setTransform(21.05,156.15,0.5,0.5);

	this.btn = new lib.Bye();
	this.btn.name = "btn";
	this.btn.setTransform(548.55,320.45,1,1,0,0,0,46,21.3);
	new cjs.ButtonHelper(this.btn, 0, 1, 1);

	this.response = new lib.Response();
	this.response.name = "response";
	this.response.setTransform(559.95,136.2,1,1,0,0,0,62.4,74.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.speechBubble},{t:this.nxtbtn}]},41).to({state:[{t:this.instance_2},{t:this.order},{t:this.servebtn},{t:this.instance_1}]},1).to({state:[{t:this.response},{t:this.btn}]},1).to({state:[]},1).to({state:[]},1).wait(15));

	// Layer_1
	this.doorbtn = new lib.door();
	this.doorbtn.name = "doorbtn";
	this.doorbtn.setTransform(318.9,293.75,1,1,0,0,0,33.5,44);
	new cjs.ButtonHelper(this.doorbtn, 0, 1, 1);

	this.instance_3 = new lib.CachedBmp_2();
	this.instance_3.setTransform(176.45,407.8,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_1();
	this.instance_4.setTransform(-151.25,-21.65,0.5,0.5);

	this.buildArea = new lib.BuildAre();
	this.buildArea.name = "buildArea";
	this.buildArea.setTransform(227.2,395.7,1,1,0,0,0,228.6,24.2);
	new cjs.ButtonHelper(this.buildArea, 0, 1, 1);

	this.bacon = new lib.Bacon();
	this.bacon.name = "bacon";
	this.bacon.setTransform(99.25,338.65,1,1,0,0,0,20,15);
	new cjs.ButtonHelper(this.bacon, 0, 1, 1);

	this.pickle = new lib.Pickle();
	this.pickle.name = "pickle";
	this.pickle.setTransform(49.65,338.65,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.pickle, 0, 1, 1);

	this.patty = new lib.Patty();
	this.patty.name = "patty";
	this.patty.setTransform(147.3,341,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.patty, 0, 1, 1);

	this.cheese = new lib.Cheese();
	this.cheese.name = "cheese";
	this.cheese.setTransform(195.8,339.8,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.cheese, 0, 1, 1);

	this.lettuce = new lib.Lettuce();
	this.lettuce.name = "lettuce";
	this.lettuce.setTransform(242.75,343.2,1,1,0,0,0,13,17.2);
	new cjs.ButtonHelper(this.lettuce, 0, 1, 1);

	this.tomato = new lib.Tomato();
	this.tomato.name = "tomato";
	this.tomato.setTransform(293.35,339.8,1,1,0,0,0,15,15);
	new cjs.ButtonHelper(this.tomato, 0, 1, 1);

	this.bread = new lib.Bread();
	this.bread.name = "bread";
	this.bread.setTransform(343.65,340.4,1,0.8387,0,0,0,17.6,18.6);
	new cjs.ButtonHelper(this.bread, 0, 1, 1);

	this.instance_5 = new lib.CachedBmp_7();
	this.instance_5.setTransform(-9.8,-13.15,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_23();
	this.instance_6.setTransform(-9.8,-13.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.doorbtn}]}).to({state:[{t:this.instance_5},{t:this.bread},{t:this.tomato},{t:this.lettuce},{t:this.cheese},{t:this.patty},{t:this.pickle},{t:this.bacon},{t:this.buildArea}]},1).to({state:[{t:this.instance_6},{t:this.bread},{t:this.tomato},{t:this.lettuce},{t:this.cheese},{t:this.patty},{t:this.pickle},{t:this.bacon},{t:this.buildArea}]},58).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(168.8,158.7,663.7,337.7);
// library properties:
lib.properties = {
	id: '9FC4AE00B20643188616C4050774146A',
	width: 640,
	height: 480,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Burger_atlas_1.png?1747896522456", id:"Burger_atlas_1"},
		{src:"images/Burger_atlas_2.png?1747896522456", id:"Burger_atlas_2"},
		{src:"images/Burger_atlas_3.png?1747896522456", id:"Burger_atlas_3"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['9FC4AE00B20643188616C4050774146A'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;